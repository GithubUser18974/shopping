import 'package:flutter/material.dart';
import 'package:test_project/src/core/app.dart';

void main() {
  runApp(
    const App(),
  );
}
